public class VIPClient extends Client {

    private double bonusInterest = 0.01;

    public VIPClient(String username, String password) {
        super(username, password);
    }

    public double getBonusInterest() {
        return bonusInterest;
    }
}