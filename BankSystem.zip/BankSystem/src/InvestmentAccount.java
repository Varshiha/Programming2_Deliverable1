public class InvestmentAccount extends Account {

    private double interestRate = 0.05;

    public InvestmentAccount(Client client) {
        super(client);
    }

    public void applyInterest() {

        double interest = balance * interestRate;

        if (client instanceof VIPClient) {
            VIPClient vip = (VIPClient) client;
            interest += balance * vip.getBonusInterest();
        }

        deposit(interest);
    }
}