public class ChequingAccount extends Account {

    public ChequingAccount(Client client) {
        super(client);
    }
}