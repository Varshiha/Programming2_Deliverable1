public class StudentClient extends Client {

    public StudentClient(String username, String password) {
        super(username, password);
    }
}