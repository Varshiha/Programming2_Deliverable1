import java.util.ArrayList;

public abstract class Account {

    protected String accountNo;
    protected double balance;
    protected Client client;
    protected ArrayList<Transaction> transactions = new ArrayList<>();

    public Account(Client client) {
        this.client = client;
        this.balance = 0;
        this.accountNo = "ACC" + (int)(Math.random() * 10000);
    }

    public String getAccountNo() { return accountNo; }
    public double getBalance() { return balance; }
    public Client getClient() { return client; }

    public ArrayList<Transaction> getTransactions() {
        return transactions;
    }

    public void deposit(double amount) {
        balance += amount;
        transactions.add(new Transaction("DEPOSIT", amount, accountNo, "Deposit"));
    }

    public void withdraw(double amount) {
        if (balance >= amount) {
            balance -= amount;
            transactions.add(new Transaction("WITHDRAW", amount, accountNo, "Withdraw"));
        }
    }
}