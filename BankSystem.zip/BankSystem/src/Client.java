import java.util.ArrayList;

public abstract class Client {

    protected int clientID;
    protected String username;
    protected String password;
    protected ArrayList<Account> accounts = new ArrayList<>();

    public Client(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public int getClientID() { return clientID; }
    public void setClientID(int id) { this.clientID = id; }

    public String getUsername() { return username; }

    public ArrayList<Account> getAccounts() { return accounts; }

    public void addAccount(Account acc) {
        accounts.add(acc);
    }

	public String getPassword() {
		return password;
	}


}