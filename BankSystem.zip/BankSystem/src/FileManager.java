import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;
public class FileManager {

	public static void saveClients(ArrayList<Client> clients) throws IOException {
		FileWriter writer = new FileWriter("clients.json");
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		ArrayList<JsonObject> json = new ArrayList<>();
		for(Client c : clients) {
			JsonObject j = new JsonObject();
			
			j.addProperty("username", c.getUsername());
			j.addProperty("password", c.getPassword());
			String type = "";
			if(c instanceof StudentClient) {
				type = "STUDENT";
			}else if(c instanceof VIPClient) {
				type = "VIP";
			}
			j.addProperty("type", type);
			json.add(j);

		}
		gson.toJson(json, writer);
		writer.close();

	}
	
	public static ArrayList<Client> loadClients() throws IOException{
		Gson gson = new Gson();
		//opens the json file and reads the file
		FileReader reader;
		try {
			reader = new FileReader("clients.json");
		}catch(FileNotFoundException e) {
			return new ArrayList<>();
		}
		
		Type listType = new TypeToken<ArrayList<JsonObject>>() {}.getType();
		ArrayList<JsonObject> objects = gson.fromJson(reader, listType);
		if(objects == null) {
			objects = new ArrayList<>();
		}
		reader.close();
		ArrayList<Client> clients = new ArrayList<>();
		
		
		for(JsonObject j  : objects) {
			Client c = null;
			if(j.get("type").getAsString().equalsIgnoreCase("STUDENT")) {
				c = new StudentClient(j.get("username").getAsString(), j.get("password").getAsString());
				
			}else if(j.get("type").getAsString().equalsIgnoreCase("VIP")) {
				c = new VIPClient(j.get("username").getAsString(), j.get("password").getAsString());
				
			}
			
			if(c != null) {
				clients.add(c);
			}
		}
        
		return clients;
		
	}

}
